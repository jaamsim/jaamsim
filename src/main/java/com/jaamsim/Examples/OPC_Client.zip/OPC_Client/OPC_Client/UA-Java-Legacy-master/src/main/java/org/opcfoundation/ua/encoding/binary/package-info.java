/**
 * The implementation of binary serialization
 */
package org.opcfoundation.ua.encoding.binary;

