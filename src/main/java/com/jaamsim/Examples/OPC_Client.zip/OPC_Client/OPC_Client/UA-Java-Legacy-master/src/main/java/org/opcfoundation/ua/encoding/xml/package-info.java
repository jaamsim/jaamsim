/**
 * The implementation of xml serialization. XmlEncoder is still TODO.
 */
package org.opcfoundation.ua.encoding.xml;

