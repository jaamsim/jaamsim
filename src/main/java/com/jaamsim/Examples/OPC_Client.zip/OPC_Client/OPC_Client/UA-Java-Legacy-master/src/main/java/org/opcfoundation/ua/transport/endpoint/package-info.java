/**
 * Endpoint related classes
 */
package org.opcfoundation.ua.transport.endpoint;

