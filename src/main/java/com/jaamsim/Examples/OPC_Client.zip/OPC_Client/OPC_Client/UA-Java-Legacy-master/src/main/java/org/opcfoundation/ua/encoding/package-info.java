/**
 * This folder contains serialization interfaces and serialization implementations
 */
package org.opcfoundation.ua.encoding;

