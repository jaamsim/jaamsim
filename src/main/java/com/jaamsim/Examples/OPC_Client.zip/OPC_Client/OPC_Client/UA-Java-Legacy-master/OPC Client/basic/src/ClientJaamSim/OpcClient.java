/*
 * JaamSim Discrete Event Simulation
 * Copyright (C) 2016 JaamSim Software Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.jaamsim.Examples;
package org.opcfoundation.ua.examples;


import java.io.IOException;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.Locale;

import org.opcfoundation.ua.application.Client;
import org.opcfoundation.ua.application.SessionChannel;
import org.opcfoundation.ua.builtintypes.LocalizedText;
import org.opcfoundation.ua.builtintypes.NodeId;
import org.opcfoundation.ua.cert.CertificateCheck;
import org.opcfoundation.ua.cert.DefaultCertificateValidator;
import org.opcfoundation.ua.cert.DefaultCertificateValidatorListener;
import org.opcfoundation.ua.cert.PkiDirectoryCertificateStore;
import org.opcfoundation.ua.cert.ValidationResult;
import org.opcfoundation.ua.core.ApplicationDescription;
import org.opcfoundation.ua.core.Attributes;
import org.opcfoundation.ua.core.BrowseDescription;
import org.opcfoundation.ua.core.BrowseDirection;
import org.opcfoundation.ua.core.BrowseResponse;
import org.opcfoundation.ua.core.BrowseResultMask;
import org.opcfoundation.ua.core.Identifiers;
import org.opcfoundation.ua.core.NodeClass;
import org.opcfoundation.ua.core.ReadResponse;
import org.opcfoundation.ua.core.ReadValueId;
import org.opcfoundation.ua.core.TimestampsToReturn;
import org.opcfoundation.ua.examples.certs.ExampleKeys;
import org.opcfoundation.ua.transport.security.Cert;
import org.opcfoundation.ua.transport.security.HttpsSecurityPolicy;
import org.opcfoundation.ua.transport.security.KeyPair;
import org.opcfoundation.ua.utils.CertificateUtils;

import static org.opcfoundation.ua.utils.EndpointUtil.selectByMessageSecurityMode;
import com.jaamsim.Graphics.DisplayEntity;
import com.jaamsim.Samples.SampleInput;
import com.jaamsim.basicsim.EntityTarget;
import com.jaamsim.events.ProcessTarget;
import com.jaamsim.input.Keyword;
import com.jaamsim.input.Output;
import com.jaamsim.input.Vec3dInput;
import com.jaamsim.math.MathUtils;
import com.jaamsim.math.Vec3d;
import com.jaamsim.units.DimensionlessUnit;
import com.jaamsim.units.DistanceUnit;
import com.jaamsim.units.RateUnit;
import com.jaamsim.units.TimeUnit;

/**
 * Example of how to create a new simulation object in JaamSim. The demo entity travels back and
 * forth between two nodes with a specified travel time.
 */

	
	

	import static org.opcfoundation.ua.utils.EndpointUtil.selectByMessageSecurityMode;
	import static org.opcfoundation.ua.utils.EndpointUtil.selectByProtocol;
	import static org.opcfoundation.ua.utils.EndpointUtil.sortBySecurityLevel;

	import java.net.InetAddress;

	import org.opcfoundation.ua.application.Client;
	import org.opcfoundation.ua.core.Attributes;
	import org.opcfoundation.ua.core.EndpointDescription;
	import org.opcfoundation.ua.core.Identifiers;
	import org.opcfoundation.ua.core.MessageSecurityMode;
	import org.opcfoundation.ua.core.ReadRequest;
	import org.opcfoundation.ua.core.ReadResponse;
	import org.opcfoundation.ua.core.ReadValueId;
	import org.opcfoundation.ua.core.TimestampsToReturn;
	import org.opcfoundation.ua.examples.certs.ExampleKeys;
	import org.opcfoundation.ua.transport.ServiceChannel;
	import org.opcfoundation.ua.transport.security.KeyPair;

import java.util.Scanner;
		
	public class OpcClient extends DisplayEntity {
		private final SampleInput r;

	  public static void main(String[] args) throws Exception {

	    ////////////// CLIENT //////////////
	    // Load Client's Application Instance Certificate from file
	    KeyPair myClientApplicationInstanceCertificate = ExampleKeys.getCert("Client");
	    // Create Client
	    Client myClient = Client.createClientApplication(myClientApplicationInstanceCertificate);
	    KeyPair myHttpsCertificate = ExampleKeys.getHttpsCert("Client");
	    myClient.getApplication().getHttpsSettings().setKeyPair(myHttpsCertificate);
	    //////////////////////////////////////


	    ////////// DISCOVER ENDPOINT /////////
	    // Discover server's endpoints, and choose one
	    String publicHostname = InetAddress.getLocalHost().getHostName();
	    System.out.println("Enter url");
	    Scanner sc = new Scanner(System.in);
	    String url = sc.nextLine();
	    EndpointDescription[] endpoints = myClient.discoverEndpoints(url);
	    // Filter out all but opc.tcp protocol endpoints
	    if (url.startsWith("opc.tcp")) {
	      endpoints = selectByProtocol(endpoints, "opc.tcp");
	      // Filter out all but Signed & Encrypted endpoints
	      endpoints = selectByMessageSecurityMode(endpoints, MessageSecurityMode.None);
	      // Filter out all but Basic128 cryption endpoints
	      // endpoints = selectBySecurityPolicy(endpoints, SecurityPolicy.BASIC128RSA15);
	      // Sort endpoints by security level. The lowest level at the
	      // beginning, the highest at the end of the array
	      endpoints = sortBySecurityLevel(endpoints);
	    } else {
	      endpoints = selectByProtocol(endpoints, "opc.https");
	    }

	    // Choose one endpoint
	    EndpointDescription endpoint = endpoints[endpoints.length - 1];
	    //////////////////////////////////////

	    //////////// TEST-STACK ////////////
	    // Create Channel
	    ServiceChannel myChannel = myClient.createServiceChannel(endpoint);
	    // Create Test Request
	    ReadValueId[] nodesToRead = {new ReadValueId(Identifiers.RootFolder, Attributes.BrowseName, null, null)};
	    ReadRequest req = new ReadRequest(null, 0.0, TimestampsToReturn.Both, nodesToRead);
	    System.out.println("REQUEST: " + req);

	    // Invoke service
	    ReadResponse res = myChannel.Read(req);
	    r=new SampleInput("RESPONSE FROM SERVER",KEY_INPUTS, null);
	    this.addInput(r);
	    // Print result
	    System.out.println("RESPONSE: " + res);
	    //////////////////////////////////////


	    ///////////// SHUTDOWN /////////////
	    // Close channel
	    myChannel.closeAsync();
	    //////////////////////////////////////
	    System.exit(0);
	  }

	}

	