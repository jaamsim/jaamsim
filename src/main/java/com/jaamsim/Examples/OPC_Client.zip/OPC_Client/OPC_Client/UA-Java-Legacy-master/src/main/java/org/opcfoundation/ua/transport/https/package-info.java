/**
 * Code for creating a HTTPS based secure channel
 */
package org.opcfoundation.ua.transport.https;

