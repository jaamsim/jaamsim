/* Copyright (c) 1996-2015, OPC Foundation. All rights reserved.
   The source code in this file is covered under a dual-license scenario:
     - RCL: for OPC Foundation members in good-standing
     - GPL V2: everybody else
   RCL license terms accompanied with this source code. See http://opcfoundation.org/License/RCL/1.00/
   GNU General Public License as published by the Free Software Foundation;
   version 2 of the License are accompanied with this source code. See http://opcfoundation.org/License/GPLv2
   This source code is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/

package org.opcfoundation.ua.common;

/**
 * <p>RuntimeServiceResultException class.</p>
 *
 */
@SuppressWarnings("serial")
public class RuntimeServiceResultException extends RuntimeException {

	/**
	 * <p>Constructor for RuntimeServiceResultException.</p>
	 *
	 * @param cause a {@link org.opcfoundation.ua.common.ServiceResultException} object.
	 */
	public RuntimeServiceResultException(ServiceResultException cause) {
		super(cause);
	}
	
	/** {@inheritDoc} */
	@Override
	public ServiceResultException getCause() {
		return (ServiceResultException) super.getCause();
	}
	
}
